var express = require('express');
var http = require('http');
var fs = require('fs');
var ejs = require('ejs');
var itemDB = require('./itemDB');
var userDB = require('./userDB');
var session = require('express-session');
var bodyParser = require('body-parser');
var cookieParser = require('cookie-parser');
var async = require('async');
var app = express();
var mongoose = require('mongoose');

app.set('view engine', 'ejs');
app.set('views','../views');
app.use('/resources', express.static('../resources'));
app.use('/js', express.static('../models'));
app.use(session({secret: "ninerGaming"}));

  app.get('/',  function(req,res){
    var username = "";
    if(req.session.theUser !== undefined){
      username = req.session.theUser.firstName + " " +req.session.theUser.lastName;
    }
    res.render('index', {username: username});
  });

  app.get('/categories', async function(req,res){
    
    var categories = ["Arcade","Adventure","Sports"];
    var username  = "";
    if( req.session.theUser !== undefined){
    username = req.session.theUser.firstName + " " +req.session.theUser.lastName; }
    res.render('categories',{categories: categories, username: username});
  });

  var myItems = require('./profileController.js');
  app.use(myItems);

  app.get('/items', async function(req, res){
    var category = req.query.category
    
    var items = await itemDB.getCategory(category);
    
    var username  = "";
    if( req.session.theUser !== undefined){
      username = req.session.theUser.firstName + " " +req.session.theUser.lastName;

        items = await userDB.filterGames(req.session.theUser.userId, items);
        
     }
    if(category === 'Arcade' || category === 'Adventure' || category === 'Sports'){
      res.render('items',{category:category, username: username, items:items});
    }else{
      res.redirect('categories');
    }
  });

  app.get('/item', async function(req, res){
  var itemCode = req.query.itemCode;
  var games = itemDB.getItems();
  var username  = "";
  if( req.session.theUser !== undefined){
    username = req.session.theUser.firstName + " " +req.session.theUser.lastName;
  }

  if(itemCode !== undefined){
      var game =   await itemDB.getItem(itemCode);
      
      var status="";
      var myItem=true;
      var userProfile = await userDB.getUserProfile(game.userId);
      if(req.session.theUser !== undefined){
        status = await userDB.getStatusOfGame(req.session.theUser.userId, itemCode);
        
        for(var i=0;i<userProfile.userItems.length;i++){
          
          if((userProfile.userItems[i].swapItem!==undefined && userProfile.userItems[i].swapItem!==null && userProfile.userItems[i].swapItem.itemCode === itemCode) || userProfile.userItems[i].item.itemCode !== itemCode){
            myItem=false;
            break;
          }
        }
      }
           
      if(game !== undefined && game !== {}){
        res.render('item', {
          item:game,
          myItem:myItem,
          username : username,
          status: status
        });
      }else{
        res.redirect("/categories");
      }
  }else{
    res.redirect("/categories");
  }
});

app.get('/swap', async function(req,res){
  var itemCode = req.query.itemCode;
   var username  = "";
   var availableGames= [];
  if( req.session.theUser !== undefined){
    username = req.session.theUser.firstName + " " +req.session.theUser.lastName;
    for(var i=0;i< req.session.currentProfile.userItems.length;i++){
      if(req.session.currentProfile.userItems[i].status === 'available'){
        availableGames.push(req.session.currentProfile.userItems[i].item);
      }
    }
  }
  if(itemCode !== undefined){
      var game = await itemDB.getItem(itemCode);
      if(game !== undefined && game !== {}){
        res.render('swap', {item:game, username: username, availableGames:availableGames});
      }else{
        res.redirect("/categories");
      }
  }else{
    res.redirect("/categories");
  }
});


    app.get('/signout', function(req, res){
    req.session.theUser = undefined;
    req.session.currentProfile = undefined;
    
    res.redirect("/categories");
    });

    app.get('/signin', function(req, res){
    res.redirect("/myItems");
    });
    
    app.get('/mySwaps', function(req, res){
    res.render('mySwaps')
    });

    app.get('/about', function(req, res){
    var username  = "";
    if( req.session.theUser !== undefined){
    username = req.session.theUser.firstName + " " +req.session.theUser.lastName; }
        res.render('about',{username:username})

    });

    app.get('/contact', function(req, res){
      var username  = "";
    if( req.session.theUser !== undefined){
    username = req.session.theUser.firstName + " " +req.session.theUser.lastName; }
        res.render('contact',{username:username})
    });

    app.get('*',function(req,res){
      res.redirect('/');
    });

app.listen(8080);
