var express = require('express');
var userDB = require('./userDB');
var bodyParser = require('body-parser');
var itemDB = require('./itemDB');
var item = require('../models/item.js');
var app = module.exports = express();
var urlencodedParser = bodyParser.urlencoded({ extended: false });

app.set('views','../views');
app.set('view engine', 'ejs');

app.get('/myItems', async function(req, res){

    var theUser = req.session.theUser;
   
    if(theUser === undefined){

        var user = await userDB.getUsers();
        req.session.theUser = user;
       
        req.session.currentProfile = await userDB.getUserProfile(user.userId);
        var userProfile = req.session.currentProfile;
       

        req.session.success = true;
        res.render('myItems', {
            success: true,
            userProfile: userProfile,
            username : user.firstName + " " + user.lastName
        });

    } else if(theUser !== null){
    	var user = req.session.theUser;
        var action = req.query.action;
        req.session.currentProfile = await userDB.getUserProfile(theUser.userId);
        var userProfile = req.session.currentProfile;
        if(action == undefined){
            res.render('myItems', {
                success: true,
                userProfile: userProfile,
                username : user.firstName + " " + user.lastName
            });
        } else if(action === 'update'){
            var itemCode = req.query.itemCode;
            var tempItem = await itemDB.getItem(itemCode);
            
            if(tempItem === null){
                res.render('myItems', {
                    success: true,
                    userProfile: userProfile,
                    username : user.firstName + " " + user.lastName
                });
            } else if (itemDB.getItem(itemCode) !== null){
            	var updateItem =  await itemDB.getItem(itemCode);
            	var check = await userDB.isValidUserItem(theUser.userId, itemCode);
            	
            	if(check && (userProfile.getUserItem(itemCode).status === "pending" || userProfile.getUserItem(itemCode).status === "offered")){

            		res.render('mySwaps',{
            			success: true,
            			swapItem: userProfile.getUserItem(itemCode),
            			userProfile: userProfile,
            			username : user.firstName + " " + user.lastName
            		});
            	}else if(check && (userProfile.getUserItem(itemCode).status === "available" || userProfile.getUserItem(itemCode).status === "swapped")){
            	var status = await userDB.getStatusOfGame(req.session.theUser.userId, itemCode);
                var myItem = true;
                for(var i=0;i<req.session.currentProfile.userItems.length;i++){
                  if(req.session.currentProfile.userItems[i].swapItem !== undefined && req.session.currentProfile.userItems[i].swapItem.itemCode === itemCode){
                    myItem =false;
                    break;
                  }
                }
                var updateItem = await itemDB.getItem(userProfile.getUserItem(itemCode).item.itemCode);
            		res.render('item',{
            			success : true,
            			item : updateItem,
            			status : status,
                        myItem : myItem,
            			username : user.firstName + " " + user.lastName
            		});
            	}else {
            		res.render('myItems', {
                		success: true,
                    //Item : userProfile.getUserItem(itemCode).item,
                		userProfile: userProfile,
                		username : user.firstName + " " + user.lastName
           			 });
        		}

            }else{
            	res.render('myItems', {
                	success: true,
                	userProfile: userProfile,
                	username : user.firstName + " " + user.lastName
            	});
        	}
        }

        if( action === "accept" || action === "reject" || action === "withdraw" ){
            var itemCode = req.query.itemCode;
            var getItemFromDb = await itemDB.getItem(itemCode);
        	
            if(getItemFromDb === null){
                res.render('mySwaps', {
                	success : true,
                	userProfile : userProfile,
                	username : user.firstName + " " + user.lastName
                });
            }else if((action === "reject" || action === "withdraw") && getItemFromDb !== null){

            	await userDB.changeUserItemStatus(req.session.theUser.userId, itemCode, "available");
                var userprof = await userDB.getUserProfile(req.session.theUser.userId);
            	res.render('mySwaps',{
            		success: true,
            		userProfile: userprof,
            		username : user.firstName + " " + user.lastName
            	});
            }else if(action === "accept" && itemDB.getItem(itemCode) !== null){

            	await userDB.changeUserItemStatus(req.session.theUser.userId, itemCode, "swapped");
                var userprof = await userDB.getUserProfile(req.session.theUser.userId);
            	//req.session.currentProfile.userItems[temp].status = "swapped";
            	res.render('mySwaps',{
            		success: true,
            		userProfile: userprof,
            		username : user.firstName + " " + user.lastName
            	});
            }
        }

        if(action === 'delete'){

        	var itemCode = req.query.itemCode;
        	req.session.currentProfile.removeUserItem(itemCode);
        	res.redirect("/myItems");
        }
    }
});

app.post("/myItems", urlencodedParser, async function(req, res){

    var swapItemCode = req.query.itemCode;
    var action = req.query.action;
    var availableItem = req.body.selectedAvailableItem;
    var userId = req.session.theUser.userId;

    if(action && action === "offer"){
        await userDB.addOffer(userId, availableItem, swapItemCode, "pending");
        res.redirect("/myItems")
    }
});

app.get('/mySwaps', function(req, res){
	var theUser = req.session.theUser;
	var currentProfile = req.session.currentProfile;

	if(theUser !== undefined && currentProfile !== undefined){
		res.render('mySwaps',{
            		success: true,
            		userProfile: currentProfile,
            		username : theUser.firstName + " " + theUser.lastName
            	});
	}else{
		res.redirect("/myItems");
	}

});
