
var itemDB = require('./itemDB.js');
var User = require('../models/user.js');
var UserItem = require('../models/userItem.js');
var UserProfile = require('../models/userProfile.js');

usersArray = [];
userProfiles = [];

var mongoose = require('mongoose');
mongoose.connect("mongodb://localhost/Ninergaming");

var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function() {

var userSchema = new mongoose.Schema({
    userId : Number,
    firstName : String,
    lastName : String,
    email : String,
    addrFirst : String,
    addrSecond : String,
    city : String,
    state : String,
    postCode : String,
    country : String,
    password: String
  
});
var userItemSchema = new mongoose.Schema({
            "userId" : Number,
            "status" : String,
            "swapItem" : {
                "itemCode": String,
                "itemName": String,
                "catalogCategory": String,
                "description": String,
                "rating": Number,
                "imageURL": String,
                "userId" : Number
            },
            "swapItemRating" : String,
            "swapperRating" : String,
            "item" : {
                "itemCode": String,
                "itemName": String,
                "catalogCategory": String,
                "description": String,
                "rating": Number,
                "imageURL": String,
                "userId" : Number
                
            }
        }, {collection:"userItems"});
     userCollection = mongoose.model("User", userSchema);
     userItemCollection = mongoose.model("userItem", userItemSchema);


});

var items = itemDB.getItems();



async function getUsers(){
    if(userCollection){
        var users = await userCollection.find();
        return users[0];
    }
}

async function getUserProfile(userId){

    if(userItemCollection){
      

        return new UserProfile(userId, await userItemCollection.find({"userId": userId}));

    }
}

async function isValidUserItem(userId, itemCode){

    var userProfile = await getUserProfile(userId);
    var userProfileItems = userProfile.userItems;
   
    for(var i=0;i< userProfileItems.length;i++){
       
        if(userProfileItems[i].item.itemCode === itemCode){
           
            return true;
        }
    }
    return false;

    
};

 async function changeUserItemStatus(userId, itemCode, status){
    if(userItemCollection){
    
        var userItem = await userItemCollection.findOne({"userId" : userId, "item.itemCode" : itemCode});
        if(status === "available"){
            await userItemCollection.findOneAndUpdate({"userId": userId, "item.itemCode":itemCode}, {$set: {"swapItem":null, "status": status}});
            await userItemCollection.findOneAndUpdate({"userId": userItem.swapItem.userId, "item.itemCode":userItem.swapItem.itemCode}, {$set: {"swapItem":null, "status": status}});
        }else if(status === "swapped"){
            await userItemCollection.findOneAndUpdate({"userId": userId, "item.itemCode":itemCode}, {$set: {"status": status}});
            await userItemCollection.findOneAndUpdate({"userId": userItem.swapItem.userId, "item.itemCode":userItem.swapItem.itemCode}, {$set: {"status": status}});
        }
};
};

async function addOffer(userId, itemCodeUser, itemCodeOtherUser, itemStatus){

    // var swapItemObj = await itemsDB.getItem(itemCodeWant.trim());
    var itemGame = await itemDB.getItem(itemCodeUser.trim());

    var swapGame = await itemDB.getItem(itemCodeOtherUser.trim());
    console.log("itemcodeUser in userDb " + itemCodeUser);

    console.log("item game in User db " + itemGame);
    console.log("item id in User db " + itemGame.userId);
    console.log("swap id in User db " + swapGame);
    console.log("swap game in User db " + swapGame.userId);

    var userItems = await userItemCollection.updateOne({"userId": userId, "item.itemCode": itemCodeUser.trim()}, {$set: {"swapItem" : swapGame, "status": "pending"}});
    var swappedUserItems = await userItemCollection.updateOne({"userId": swapGame.userId, "item.itemCode": itemCodeOtherUser.trim()}, {$set: {"swapItem" : itemGame, "status": "offered"}});

};

async function filterGames(userId, games){
    
    result=[];
    userGames = [];
    var userProfile = await getUserProfile(userId);
    for(var i=0;i < userProfile.userItems.length;i++){ 
        userGames.push(userProfile.userItems[i].item);
    }

    for(var i=0;i<games.length;i++){
        var isFound = false;
        for(var j=0; j<userGames.length;j++){
            if(games[i].itemCode ===  userGames[j].itemCode){
                isFound = true;
               
                break;     
            }
        }
        if(!isFound){
            result.push(games[i]);
        }
    }
   

    return result;
}
    // result=[];
    // userGames = [];
    // for(var i=0;i < getUserProfile(userId).userItems.length;i++){
    //     userGames.push(getUserProfile(userId).userItems[i].item);
    // }
    // console.log("FilterGames - gamesArray "+userGames);
    // for(var i=0;i<gamesArray.length;i++){
    //     var isFound = false;
    //     for(var j=0; j<userGames.length;j++){
    //         console.log(gamesArray[i].itemCode + " "+userGames[j].itemCode+" "+i+" "+j);
    //         if(gamesArray[i].itemCode ===  userGames[j].itemCode){
    //             isFound = true;
    //             break;
    //             //console.log(games[i].itemCode + " "+userMovies[j].itemCode+" "+i+" "+j);             
    //         }
    //     }
    //     if(!isFound){
    //         result.push(gamesArray[i]);
    //     }
    // }

    // return result;


async function getStatusOfGame(userId, itemCode){

    var userProfile = await getUserProfile(userId);
   
    var userItems = userProfile.userItems;
    
    for(var i=0;i<userItems.length; i++){
        if(userItems[i].item.itemCode === itemCode || (userItems[i].swapItem !== undefined && userItems[i].swapItem.itemCode === itemCode))
            return userItems[i].status;
        }
        
    return "";
}

module.exports = {
    getUsers: getUsers,
    getUserProfile: getUserProfile,
    isValidUserItem : isValidUserItem,
    changeUserItemStatus: changeUserItemStatus,
    filterGames: filterGames,
    getStatusOfGame: getStatusOfGame,
    addOffer: addOffer


}
