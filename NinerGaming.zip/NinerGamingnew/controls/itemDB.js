var item = require('../models/item.js');
var swap = require('../views/swap.ejs');
games= [];
var itemCollection;
var mongoose = require('mongoose');
mongoose.connect("mongodb://localhost/Ninergaming");

var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function() {
  console.log("we're connected!");
var gameSchema = new mongoose.Schema({
    itemCode: String,
    itemName: String,
    catalogCategory: String,
    description: String,
    rating: String,
    imageURL: String,
    userId: Number
  
});
 itemCollection = mongoose.model("Item", gameSchema);
});

async function addItem(item){
    if(itemCollection){
        await itemCollection.insert(item);
    }

 }

 async function addItem(itemCode, itemName, itemCategory, rating, itemDescription, imageUrl, bgUrl, userId){
    if(itemCollection){
        await itemCollection.insert({
            "itemCode" : itemCode,
            "itemName" : itemName,
            "catalogCategory" : itemCategory,
            "description" : itemDescription,
            "rating" : rating,
            "imageURL" : imageUrl,
            "userId" : userId
            
            
        });
    }

 }



// gamesArray.push(item.item("pacman", "Pacman", "Arcade", "Pac-Man, stylized as PAC-MAN, is an arcade game developed by Namco and first released in Japan as Puck Man in May 1980", 4, "resources/images/pacman.jpg"));
// gamesArray.push(item.item("mario", "Super Mario", "Arcade", "Super Mario Bros. is a platform video game developed and published by Nintendo. The successor to the 1983 arcade game, Mario Bros., it was released in Japan in 1985", 4, "resources/images/mario.png"));
// gamesArray.push(item.item("contra", "Contra", "Arcade", "Contra is a run and gun video game developed and published by Konami, originally released as a coin-operated arcade game on February 20, 1987", 4, "resources/images/contra.jpg"));
// gamesArray.push(item.item("cell", "Splinter Cell", "Adventure", "Tom Clancy's Splinter Cell: Blacklist is an action-adventure stealth video game developed by Ubisoft Toronto and published by Ubisoft", 3, "../resources/images/cell.jpg"));
// gamesArray.push(item.item("pubg", "PubG", "Adventure", "PlayerUnknown's Battlegrounds is an online multiplayer battle royale game developed and published by PUBG Corporation, a subsidiary of South Korean video game company Bluehole", 4, "../resources/images/pub.png"));
// gamesArray.push(item.item("creed", "Assassins Creed", "Adventure", "Assassin's Creed Unity is an action-adventure video game developed by Ubisoft Montreal and published by Ubisoft.", 5, "../resources/images/creed.jpeg"));
// gamesArray.push(item.item("fifa", "Fifa 2018", "Sports", "FIFA 18 is a football simulation video game in the FIFA series of video games, developed and published by Electronic Arts and was released worldwide on 29 September 2017.", 4, "../resources/images/fifa.jpeg"));
// gamesArray.push(item.item("nba", "Nba 2k18", "Sports", "NBA 2K18 is a basketball simulation video game developed by Visual Concepts and published by 2K Sports. It is the 19th installment in the NBA 2K franchise.", 5, "../resources/images/nba.jpg"));
// gamesArray.push(item.item("cricket", "Don Bradman 2017", "Sports", "Don Bradman Cricket 17 is a cricket video game developed by Big Ant Studios. It is the sequel to Don Bradman Cricket 14 and was released on 16 December 2016 for PlayStation 4.", 3, "../resources/images/don.jpg"));


 function getItems(){
     if(itemCollection){
        return itemCollection.find();
    }
};

async function getItem(itemID){

     if(itemCollection){
        
        return await itemCollection.findOne({itemCode: itemID});
    }

    // games = [];
    // for(var i = 0; i < gamesArray.length; i++){
    //     if(itemID === gamesArray[i].itemCode){
    //         games.push(gamesArray[i]);
    //     }
    // }
    // if(games.length > 0){
    //     return games[0];
    // } else {
    //     return undefined;
    // }
};


  function getCategory(catalogCategory){
    
        if(itemCollection){
        return itemCollection.find({"catalogCategory": catalogCategory});
      }  
};

module.exports = {
    getItem: getItem,
    getItems: getItems,
    getCategory: getCategory
}
