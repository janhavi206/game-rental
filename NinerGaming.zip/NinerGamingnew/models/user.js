var user = function(userId, firstName, lastName, email, addrFirst, addrSecond, city, state, postCode, country){
	this.userId = userId;
	this.firstName = firstName;
	this.lastName = lastName;
	this.email = email;
	this.addrFirst = addrFirst;
	this.addrSecond = addrSecond;
	this.city = city;
	this.state = state;
	this.postCode = postCode;
	this.country = country;
}

module.exports = user;
