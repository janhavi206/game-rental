var userProfile = function (userId, userItems, lastName, email, addr1, addr2, city, state, zip, country) {
    this.userId = userId;
    this.userItems = userItems;

    // this.userProfile = {
    //     userId : this.userId ,
    //     userItems : this.userItems
    // };

    this.removeUserItem = function(itemCode){
        console.log("Delete button");
        for(var i = 0; i< this.userItems.length; i++){
            if(itemCode === this.userItems[i].item.itemCode){
                this.userItems.splice(i,1);
                break;
            }
        }
    //this.userProfile.userItems = this.userItems;
    };

    this.getUserItems = function(){
        return this.userItems;
    };

    this.getUserItem = function(itemCode){
        for(var i=0;i<this.userItems.length;i++){
            if(itemCode === this.userItems[i].item.itemCode){
                return this.userItems[i];
            }
        }
        return null;
    }

    this.emptyProfile = function(){
        this.userItems = null;
        this.userId = null;
    };

    this.addItem = function(userItem){
        this.userItems.push(userItem);
    }

    // return userProfile;
};


module.exports = userProfile;
