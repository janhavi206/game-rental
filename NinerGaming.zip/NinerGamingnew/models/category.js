
function submitButton(){
  location.href = '/myitems' ;
}

function updateButton(){
  location.href = '/mySwaps' ;
}

function withdrawButton(input){
  
  location.href = '/myItems?action=withdraw&itemCode='+ input ;
}

function acceptButton(input){
	console.log("button - "+ input);
  location.href = '/myItems?action=accept&itemCode='+ input ;

}

function rejectButton(input){
  location.href = '/myItems?action=reject&itemCode='+ input ;
}





