var userItem = function(item, rating, status, swapItem, swapItemRating, swapperRating){
	this.item=item;
	this.rating=rating;
	this.status=status;
	this.swapItem=swapItem;
	this.swapItemRating=swapItemRating;
	this.swapperRating=swapperRating;

	

};
module.exports = userItem;
